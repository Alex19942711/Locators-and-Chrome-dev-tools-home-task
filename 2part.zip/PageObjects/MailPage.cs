﻿using System;
using OpenQA.Selenium;

namespace SeleniumDemo.PageObjects
{
	public class MailPage
	{

        private IWebDriver driver;
        public MailPage(IWebDriver _driver)
        {
            this.driver = _driver;
        }

        public IWebElement CreateNewMessageButton => driver.FindElement(By.XPath("//span[contains(@class,'Button-label ZZgmc')]"));
        public IWebElement ReceiverTextBox => driver.FindElement(By.XPath("//div[contains(@class,'QdX2d')]"));
        public IWebElement SubjectTextBox => driver.FindElement(By.CssSelector("[id*='TextField']"));
        public IWebElement ContentTextBox => driver.FindElement(By.XPath("//div[contains(@class,'dbf5I')]"));
        public IWebElement SendMessageButton => driver.FindElement(By.XPath("//*[contains(@class,'ms-Button--primary')]"));
        public IWebElement MessageReportButton => driver.FindElement(By.XPath("//div[@draggable='true']/div[@title='Надіслані'][1]"));
       
    }
}

