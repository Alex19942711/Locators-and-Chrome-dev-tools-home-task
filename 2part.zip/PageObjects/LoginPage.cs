﻿using OpenQA.Selenium;

namespace SeleniumDemo.PageObjects
{
    public class LoginPage
    {
        private IWebDriver driver;
        public LoginPage(IWebDriver _driver)
        {
            this.driver = _driver;
        }

        public IWebElement SignInButton => driver.FindElement(By.CssSelector("[data-m*='P6'][class*='sign']"));
        public IWebElement LoginField => driver.FindElement(By.XPath("//input[@type='email']"));
        public IWebElement ContinueButton => driver.FindElement(By.XPath("//input[@type='submit']"));
        public IWebElement PasswordField => driver.FindElement(By.XPath("//input[@type='password']"));
        public IWebElement ContinueButtonDoNotOutSystem => driver.FindElement(By.XPath("//input[contains(@id,'idSIButton')]"));

        public IWebElement ProfilePicture => driver.FindElement(By.XPath("//div[@id='O365_MainLink_MePhoto']"));
    }
}
