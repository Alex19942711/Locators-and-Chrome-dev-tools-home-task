﻿using System;
using OpenQA.Selenium.Support.UI;
using SeleniumDemo.PageObjects;
using SeleniumDemo.WebElementsHelpers;
using OpenQA.Selenium;

namespace SeleniumDemo.Handlers
{
    public  class InboxPageSteps : BaseTest
    {
        readonly WebDriverWait wait;
        public MailPage MailPage { get; set; }

        public InboxPageSteps()
        {
            wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(10));
            MailPage = new MailPage(Driver);
        }
        public void ClickCreateMessageButton()
        {
            WaitExtension.WaitFor(3);
            WaitExtension.WaitElementEnabled(Driver, MailPage.CreateNewMessageButton);
            MailPage.CreateNewMessageButton.Click();

        }

        public void FillInReceiver(string email)
        {
            
            WaitExtension.WaitElementEnabled(Driver, MailPage.ReceiverTextBox);
            MailPage.ReceiverTextBox.SendKeys(email);
        }

        public void FillInSubject(string subject)
        {
            
            WaitExtension.WaitElementEnabled(Driver, MailPage.SubjectTextBox);
            MailPage.SubjectTextBox.SendKeys(subject);
        }

        public void FillInContent(string content)
        {
            
            WaitExtension.WaitElementEnabled(Driver, MailPage.ContentTextBox);
            MailPage.ContentTextBox.SendKeys(content);
        }

        public void SendMessage()
        {
            WaitExtension.WaitFor(3);
            WaitExtension.WaitElementEnabled(Driver, MailPage.SendMessageButton);
            MailPage.SendMessageButton.Click();

        }

        public void SentMessages()
        {
            WaitExtension.WaitFor(3);
            MailPage.MessageReportButton.Click();
        }

        public bool CheckSentMessage()
        {
            try
            {
                Driver.PageSource.Contains( _SentMessage);
                return true;
            }
            catch (NoSuchElementException)
            {
                return false;
            }

        }

     

    }

}
