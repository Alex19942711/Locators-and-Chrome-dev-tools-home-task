﻿using System;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;


namespace SeleniumDemo.Handlers
{
    public abstract class BaseTest
    {
        public static string BaseURL = "https://outlook.live.com/owa/";
        public readonly string _SentMessage = "Hello,Epam!";
        public static IWebDriver Driver = new FirefoxDriver(); //change to Firefox driver if you want

        public static void OpenPage(string UrlToOpen)
        {
            Driver.Navigate().GoToUrl(UrlToOpen);
        }


        
    }
}
