﻿using System;
using System.Threading;
using NUnit.Framework;
using SeleniumDemo.Handlers;
using SeleniumDemo.WebElementsHelpers;

namespace SeleniumDemo.Tests
{
    public class LoginTests : BaseTest
    {
        private LoginPageSteps LoginPageSteps { get; set; }
        private InboxPageSteps InboxPageSteps { get; set; }

        [SetUp]
        public void Setup()
        {
            OpenPage(BaseURL);
            Driver.Manage().Window.Maximize();
            LoginPageSteps = new LoginPageSteps();
            InboxPageSteps = new InboxPageSteps();
        }

        [Test]
        public void VerifyAbilityToLoginIntoAccount()
        {

            LoginPageSteps.ClickSignInButton();
            LoginPageSteps.EnterLogin("oleksandrrohachov@hotmail.com");
            LoginPageSteps.ClickContinueButton();
            LoginPageSteps.EnterPassword("Nokia19942711");
            LoginPageSteps.ClickContinueButton();
            LoginPageSteps.AcceptEnterToAccount();

            WaitExtension.WaitFor(5);
            WaitExtension.WaitUntilPageLoad(Driver, 10);
            Assert.IsTrue(LoginPageSteps.GetElement("Profile Picture").Displayed, "Profile picture is not displayed");
            

        }



        [Test]
        public void VerifySentMessageToReceiver()
        {
            
            InboxPageSteps.ClickCreateMessageButton();
            WaitExtension.WaitFor(3);
            InboxPageSteps.FillInReceiver("olexasanderrogachov@gmail.com");
            InboxPageSteps.FillInSubject("Hello,Epam!");
            InboxPageSteps.FillInContent("Hello,World!");
            InboxPageSteps.SendMessage();
            InboxPageSteps.SentMessages();
            WaitExtension.WaitFor(5);
            Assert.IsTrue(InboxPageSteps.CheckSentMessage());
            
        }
    
        
           

        [OneTimeTearDown]
        public void DoAfterTheTests()
        {
            BaseURL = null;
            Driver.Close();
            Driver.Quit();
        }


    }

}
