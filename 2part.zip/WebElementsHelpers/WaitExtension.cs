﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SeleniumDemo.WebElementsHelpers
{
    public class WaitExtension
    {
        private static WebDriverWait wait;
        public static void WaitElementEnabled(IWebDriver driver, IWebElement webElement)
        {
            wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            wait.Until(s => webElement.Enabled);
        }
        static void WaitElementDisplayed(IWebDriver driver, IWebElement webElement)
        {
            wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            wait.Until(s => webElement.Displayed);
        }

        public static void WaitUntilPageLoad(IWebDriver driver, double seconds)
        {
            driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(seconds);

        }


        public static void WaitFor(int time)
        {
            Thread.Sleep(TimeSpan.FromSeconds(time));
        }
    }
}
