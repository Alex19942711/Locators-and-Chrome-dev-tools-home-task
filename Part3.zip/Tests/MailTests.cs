﻿using System;
using NUnit.Framework;
using SeleniumDemo.Handlers;
using SeleniumDemo.Tests.TestData;
using SeleniumDemo.WebElementsHelpers;

namespace SeleniumDemo.Tests
{
    public class MailTests : BaseTest
    {
        private InboxPageSteps InboxPageSteps { get; set; }
        private LoginPageSteps LoginPageSteps { get; set; }
        

       [OneTimeSetUp]
        public void Setup()
        {

            OpenPage(BaseURL);
            Driver.Manage().Window.Maximize();
            LoginPageSteps = new LoginPageSteps();
            InboxPageSteps = new InboxPageSteps();

            Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(0);
        }

        [Test]
        public void VerifySentMessageToReceiver()
        {
            WaitExtension.WaitFor(3);
            InboxPageSteps.ClickCreateMessageButton();
            WaitExtension.WaitFor(3);
            InboxPageSteps.FillInReceiver(UserProfile.TestEmail);
            InboxPageSteps.FillInSubject("Hello,Epam!");
            InboxPageSteps.FillInContent("Hello,World!");
            InboxPageSteps.SendMessage();
            InboxPageSteps.OpenSentMessages();
            WaitExtension.WaitFor(5);
            Assert.IsTrue(InboxPageSteps.IsMessageSent(),"Sent message is not been found on the sent folder");

        }

        [OneTimeTearDown]
        public void DoAfterTheTests()
        {
            BaseURL = null;
            Driver.Close();
        }
        
    }
}
