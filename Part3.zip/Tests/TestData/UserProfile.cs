﻿using System;
namespace SeleniumDemo.Tests.TestData
{
	public class UserProfile
	{
		public static string UserLogin = "oleksandrrohachov@hotmail.com";
		public static string UserPassword = "Nokia19942711";
		public static string TestEmail = "olexasanderrogachov@gmail.com";
	}
	
}

