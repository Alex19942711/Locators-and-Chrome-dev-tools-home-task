﻿using System;
using System.Threading;
using NUnit.Framework;
using SeleniumDemo.Handlers;
using SeleniumDemo.Tests.TestData;
using SeleniumDemo.WebElementsHelpers;

namespace SeleniumDemo.Tests
{
    public class LoginTests : BaseTest
    {
        private LoginPageSteps LoginPageSteps { get; set; }
       

        [OneTimeSetUp]
        public void Setup()
        {
            OpenPage(BaseURL);
            Driver.Manage().Window.Maximize();
            LoginPageSteps = new LoginPageSteps();
           
        }

        [Test]
        public void VerifyAbilityToLoginIntoAccount()
        {

            LoginPageSteps.ClickSignInButton();
            LoginPageSteps.EnterLogin(UserProfile.UserLogin);
            LoginPageSteps.ClickContinueButton();
            LoginPageSteps.EnterPassword(UserProfile.UserPassword);
            LoginPageSteps.ClickContinueButton();
            LoginPageSteps.AcceptEnterToAccount();

            WaitExtension.WaitFor(3);
            WaitExtension.WaitUntilPageLoad(Driver, 20);
            Assert.IsTrue(LoginPageSteps.GetElement("Profile Picture").Displayed, "Profile picture is not displayed");

        }

        [OneTimeTearDown]
        public void DoAfterTheTests()
        {
            
        }
    }
}
