﻿using System;
using System.Collections.Generic;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumDemo.PageObjects;
using SeleniumDemo.WebElementsHelpers;

namespace SeleniumDemo.Handlers
{
    public class LoginPageSteps : BaseTest
    {
        readonly WebDriverWait wait;

        public LoginPage LoginPage;

        public LoginPageSteps()
        {
            wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(10));
            LoginPage = new LoginPage(Driver);
        }
        public void WaitElementEnabled(IWebElement element)
        {
            wait.Until(s => element.Enabled);
        }

        public void ClickSignInButton()
        {
            WaitExtension.WaitElementEnabled(Driver, LoginPage.SignInButton); 

            LoginPage.SignInButton.Click();
        }


        public void EnterLogin(string login)
        {
            WaitExtension.WaitFor(2);
            WaitExtension.WaitElementEnabled(Driver, LoginPage.LoginField);
            LoginPage.LoginField.SendKeys(login);
        }



        public void EnterPassword(string password)
        {
            WaitExtension.WaitFor(2);
            WaitExtension.WaitUntilPageLoad(Driver, 20);
            WaitExtension.WaitElementEnabled(Driver, LoginPage.PasswordField);
            LoginPage.PasswordField.SendKeys(password);

        }

        public void ClickContinueButton()
        {
            WaitExtension.WaitFor(3);
            LoginPage.ContinueButton.Click();
        }

        public void AcceptEnterToAccount()
        {
            WaitExtension.WaitFor(3);
            WaitExtension.WaitElementEnabled(Driver, LoginPage.ContinueButtonDoNotOutSystem);
            LoginPage.ContinueButtonDoNotOutSystem.Click();
        }

        public IWebElement GetElement(string webElement)
        {
            var allElements = new Dictionary<string, IWebElement>()
        {
            { "Profile Picture", LoginPage.ProfilePicture}

        };
            return allElements[webElement];
        }



        
    }
}

